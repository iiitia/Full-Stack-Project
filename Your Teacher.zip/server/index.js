
const http = require("http");
const express = require("express");
const cors = require("cors");
const socketIO = require("socket.io");
const multer = require("multer");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

const PORT = process.env.PORT || 4500;

// Middleware
app.use(cors());
 // Serve uploaded files

// Multer storage configuration
// Set up storage for multer
// Set up multer for in-memory storage
const storage = multer.memoryStorage();
const upload = multer({ storage });

app.post('/StudyMaterial', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }
    
    // Here you can handle the file (e.g., send it back, process it, etc.)
    // For demonstration, we're just returning the file's original name
    res.send(`File uploaded: ${req.file.originalname}`);
})


// Endpoint to handle file uploads

// Serve a simple welcome message on the root URL
app.get("/", (req, res) => {
    res.send("Chat server is running!");
});

// Handle file uploads

// Set up storage for multer



// Endpoint to handle file uploads

// Store users in an object for tracking
const users = {};

// Handle socket connections
io.on("connection", (socket) => {
    console.log("New connection:", socket.id);

    socket.on('joined', ({ user }) => {
        users[socket.id] = user;
        console.log(`${user} has joined the chat`);
        
        socket.broadcast.emit('userJoined', { user: "Admin", message: `${user} has joined the chat` });
        socket.emit('welcome', { user: "Admin", message: `Welcome to the chat, ${user}!` });
    });

    socket.on('message', ({ message, id }) => {
        io.emit('sendMessage', { user: users[id], message, id });
    });

    socket.on('disconnect', () => {
        const user = users[socket.id];
        socket.broadcast.emit('leave', { user: "Admin", message: `${user} has left the chat` });
        delete users[socket.id];
        console.log(`${user} has left the chat`);
    });
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
