
import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Join from "./component/Join/Join";
import Chat from "./component/Chat/Chat";
import Progress from "./component/Progress/Progress";
import StudyMaterial from "./component/StudyMaterial/StudyMaterial";



function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Join />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/StudyMaterial" element={<StudyMaterial />} />
      
        <Route path="/Progress" element={<Progress />} />
      </Routes>

      {/* Schedule Component */}
     
    </Router>
  );
}

export default App;
