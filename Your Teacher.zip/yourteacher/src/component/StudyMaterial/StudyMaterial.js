
import React, { useState } from 'react';
import './StudyMaterial.css';

const StudyMaterial = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [notes, setNotes] = useState('');
    const [editingIndex, setEditingIndex] = useState(null);
    const [savedNotes, setSavedNotes] = useState([]);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const fileUrl = URL.createObjectURL(file); // Create a URL for the file
            const newFile = { name: file.name, url: fileUrl, notes: '' };
            setUploadedFiles([...uploadedFiles, newFile]); // Update the list of uploaded files
            setSelectedFile(null); // Reset selected file
        }
    };

    const handleSaveNotes = () => {
        if (editingIndex !== null) {
            const updatedFiles = uploadedFiles.map((file, index) =>
                index === editingIndex ? { ...file, notes } : file
            );
            setUploadedFiles(updatedFiles);
            setEditingIndex(null);
        } else {
            setSavedNotes([...savedNotes, notes]);
        }
        setNotes('');
    };

    const handleEditFile = (index) => {
        setNotes(uploadedFiles[index].notes);
        setEditingIndex(index);
    };

    const handleDeleteFile = (index) => {
        const updatedFiles = uploadedFiles.filter((_, i) => i !== index);
        setUploadedFiles(updatedFiles);
        if (editingIndex === index) {
            setEditingIndex(null);
        }
    };

    const handleDeleteSavedNote = (index) => {
        const updatedNotes = savedNotes.filter((_, i) => i !== index);
        setSavedNotes(updatedNotes);
    };

    const downloadNotes = (index) => {
        const element = document.createElement("a");
        const file = new Blob([savedNotes[index]], { type: 'text/plain' });
        element.href = URL.createObjectURL(file);
        element.download = `note_${index + 1}.txt`;
        document.body.appendChild(element);
        element.click();
    };

    return (
        <div>
            <h2>Study Material</h2>
            <input type="file" onChange={handleFileChange} />

            <h3>Write Notes:</h3>
            <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows="5"
                style={{ width: '100%', marginBottom: '20px' }}
                placeholder="Write your notes here..."
            />

            <button onClick={handleSaveNotes}>
                {editingIndex !== null ? 'Update Notes' : 'Save Notes'}
            </button>

            <h3>Uploaded Files:</h3>
            <ul>
                {uploadedFiles.map((file, index) => (
                    <li key={index}>
                        <a href={file.url} target="_blank" rel="noopener noreferrer">{file.name}</a>
                        <button onClick={() => handleEditFile(index)} style={{ marginLeft: '10px' }}>Edit Notes</button>
                        <button onClick={() => handleDeleteFile(index)} style={{ marginLeft: '10px' }}>Delete</button>
                        {file.notes && <p style={{ marginTop: '10px' }}>{file.notes}</p>}
                        <a href={file.url} download={file.name} style={{ marginLeft: '10px' }}>Download File</a>
                    </li>
                ))}
            </ul>

            <h3>Saved Notes:</h3>
            <ul>
                {savedNotes.map((note, index) => (
                    <li key={index}>
                        <p>{note}</p>
                        <button onClick={() => downloadNotes(index)}>Download Note</button>
                        <button onClick={() => handleDeleteSavedNote(index)} style={{ marginLeft: '10px' }}>Delete Note</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StudyMaterial;
